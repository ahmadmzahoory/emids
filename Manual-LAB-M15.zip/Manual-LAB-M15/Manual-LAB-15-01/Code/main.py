from google.cloud.storage import Client

def stats_compute(event, context):
    """Cloud Function to be triggered by Cloud Storage.
    Args:
        event (dict):  The dictionary with data specific to this type of event.
                       The `data` field contains a description of the event in
                       the Cloud Storage `object` format described here:
                       https://cloud.google.com/storage/docs/json_api/v1/objects#resource
        context (google.cloud.functions.Context): Metadata of triggering event.
    Returns:
        None; the output is written to Stackdriver Logging
    """
    bucket_name = event['bucket']
    print(f'Bucket: {bucket_name}')
    file_name = event['name']
    print(f'File: {file_name}')
    client = Client()
    bucket = client.get_bucket(bucket_name)
    blob = bucket.get_blob(file_name)
    downloaded_file = blob.download_as_text(encoding="utf-8")
    lst_int = [int(x) for x in downloaded_file.split("\n") if len(x) >= 1]
    minimum = min(lst_int)
    print(f"The minimum number in the file is: {minimum}")
    maximum = max(lst_int)
    print(f"The maximum number in the list is: {maximum}")
    average = sum(lst_int) / len(lst_int)
    print(f"The average value of the numbers in the file is: {average}")
