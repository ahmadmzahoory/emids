from main import stats_compute
import os

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = r"Credentials_File_Path"
event = {}
event["bucket"] = "calculator-input-123"
event["name"] = "numbers.txt"
stats_compute(event, {})
