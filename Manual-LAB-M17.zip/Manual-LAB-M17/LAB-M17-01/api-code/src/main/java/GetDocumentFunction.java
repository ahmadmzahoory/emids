import com.google.cloud.functions.HttpFunction;
import com.google.cloud.functions.HttpRequest;
import com.google.cloud.functions.HttpResponse;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.FirestoreOptions;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

public class GetDocumentFunction implements HttpFunction {

    private final Firestore db;

    public GetDocumentFunction() {
        // Initialize Firestore
        FirestoreOptions firestoreOptions = FirestoreOptions.getDefaultInstance().toBuilder()
                .setProjectId("PROJECT-ID") // Replace with your project ID
                .build();
        db = firestoreOptions.getService();
    }

    @Override
    public void service(HttpRequest request, HttpResponse response) throws Exception {
        // Get document ID from request query parameter
        String documentId = request.getFirstQueryParameter("documentId").orElse(null);
        if (documentId == null || documentId.isEmpty()) {
            sendErrorResponse(response, "Document ID is missing");
            return;
        }

        // Get document reference
        DocumentReference docRef = db.collection("products").document(documentId);

        // Fetch document synchronously
        try {
            DocumentSnapshot document = docRef.get().get();
            JsonObject jsonResponse = new JsonObject();
            if (document.exists()) {
                jsonResponse.addProperty("status", "success");
                jsonResponse.add("data", new Gson().toJsonTree(document.getData()));
            } else {
                jsonResponse.addProperty("status", "error");
                jsonResponse.addProperty("message", "No such document");
            }
            sendResponse(response, jsonResponse.toString());
        } catch (InterruptedException | ExecutionException e) {
            sendErrorResponse(response, "get failed with " + e.getMessage());
        }
    }

    private void sendResponse(HttpResponse response, String jsonResponse) throws IOException {
        response.setStatusCode(200);
        response.setContentType("application/json");
        response.appendHeader("Access-Control-Allow-Origin", "*");
        response.appendHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.appendHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
        try {
            response.getWriter().write(jsonResponse);
        } catch (IOException e) {
            e.printStackTrace(); // Or handle the exception appropriately
        }
    }

    private void sendErrorResponse(HttpResponse response, String message) throws IOException {
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.addProperty("status", "error");
        jsonResponse.addProperty("message", message);
        response.setStatusCode(500);
        response.setContentType("application/json");
        response.appendHeader("Access-Control-Allow-Origin", "*");
        response.appendHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.appendHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
        try {
            response.getWriter().write(jsonResponse.toString());
        } catch (IOException e) {
            e.printStackTrace(); // Or handle the exception appropriately
        }
    }
}
