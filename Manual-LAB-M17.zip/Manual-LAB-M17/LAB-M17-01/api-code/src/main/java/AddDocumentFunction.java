import com.google.cloud.functions.HttpFunction;
import com.google.cloud.functions.HttpRequest;
import com.google.cloud.functions.HttpResponse;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.FirestoreOptions;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.json.JSONObject;
import org.json.XML;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AddDocumentFunction implements HttpFunction {

    private static final Logger logger = Logger.getLogger(AddDocumentFunction.class.getName());

    private final Firestore db;

    public AddDocumentFunction() {
        // Initialize Firestore
        FirestoreOptions firestoreOptions = FirestoreOptions.getDefaultInstance().toBuilder()
                .setProjectId("PROJECT-ID") // Replace with your project ID
                .build();
        db = firestoreOptions.getService();
    }

    @Override
    public void service(HttpRequest request, HttpResponse response) throws Exception {
        if (request.getMethod().equalsIgnoreCase("OPTIONS")) {
            handlePreflight(response);
            return;
        }

        String contentType = request.getContentType().orElse("");

        // Read the request body
        BufferedReader reader = request.getReader();
        StringBuilder requestBodyBuilder = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            requestBodyBuilder.append(line);
        }
        String requestBodyStr = requestBodyBuilder.toString();

        logger.info("Received request body: " + requestBodyStr);

        JsonObject requestBody = null;

        if (contentType.equals("application/json")) {
            try {
                requestBody = new Gson().fromJson(requestBodyStr, JsonObject.class);
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error parsing JSON payload", e);
                sendErrorResponse(response, "Error parsing JSON payload: " + e.getMessage());
                return;
            }
        } else if (contentType.equals("application/xml")) {
            try {
                JSONObject xmlJSONObj = XML.toJSONObject(requestBodyStr);
                String jsonStr = xmlJSONObj.toString();
                logger.info("Json after XML conversion: " + jsonStr);
                requestBody = new Gson().fromJson(jsonStr, JsonObject.class);
                logger.info("requestBody after XML conversion: " + requestBody.toString());
            } catch (Exception e) {
                logger.log(Level.SEVERE, "Error parsing XML payload", e);
                sendErrorResponse(response, "Invalid XML payload");
                return;
            }
        } else {
            sendErrorResponse(response, "Unsupported content type");
            return;
        }

        JsonObject product = requestBody.has("product") ? requestBody.getAsJsonObject("product") : requestBody;

        if (product == null || !product.has("id") || !product.has("product_name")
                || !product.has("product_price") || !product.has("product_quantity")) {
            logger.info("requestBody error: " + product.toString());
            sendErrorResponse(response, "Invalid request payload");
            return;
        }

        // Prepare data to be added
        Map<String, Object> data = new HashMap<>();
        data.put("id", product.get("id").getAsString());
        data.put("product_name", product.get("product_name").getAsString());
        data.put("product_price", product.get("product_price").getAsString());
        data.put("product_quantity", product.get("product_quantity").getAsString());

        try {
            DocumentReference docRef = db.collection("products").document();
            docRef.set(data);
            logger.info("Document added successfully with ID: " + docRef.getId());
            sendResponse(response, "Product added successfully");
        } catch (Exception e) {
            String errorMessage = "Error adding document: " + e.getMessage();
            logger.log(Level.SEVERE, errorMessage, e);
            sendErrorResponse(response, errorMessage);
        }
    }

    private void sendResponse(HttpResponse response, String jsonResponse) throws IOException {
        response.setStatusCode(200);
        response.appendHeader("Access-Control-Allow-Origin", "*");
        response.appendHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.appendHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
        response.setContentType("application/json");
        response.getWriter().write(jsonResponse);
    }

    private void sendErrorResponse(HttpResponse response, String message) throws IOException {
        JsonObject jsonResponse = new JsonObject();
        jsonResponse.addProperty("status", "error");
        jsonResponse.addProperty("message", message);
        response.setStatusCode(500);
        response.appendHeader("Access-Control-Allow-Origin", "*");
        response.appendHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.appendHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
        response.setContentType("application/json");
        response.getWriter().write(jsonResponse.toString());
    }

    private void handlePreflight(HttpResponse response) throws IOException {
        response.setStatusCode(204); // No Content
        response.appendHeader("Access-Control-Allow-Origin", "*");
        response.appendHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        response.appendHeader("Access-Control-Allow-Headers", "Authorization, Content-Type");
        response.appendHeader("Access-Control-Max-Age", "3600");
    }
}
