import os
from google.cloud import pubsub_v1

os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = r"CREDENTIALS-PATH"
project_id = "PROJECT-ID"

def create_topic(topic_id):
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_id)
    topic = publisher.create_topic(request={"name": topic_path})
    print(f"Created topic: {topic.name}")
    return topic_path

def publish_message(topic_id, data: str, attributes: dict = None, ordering_key: str = None):
    publisher = pubsub_v1.PublisherClient(publisher_options = pubsub_v1.types.PublisherOptions(enable_message_ordering=True,))
    topic = publisher.topic_path(project_id, topic_id)
    if ordering_key and attributes:
        future = publisher.publish(topic, data=data.encode("utf-8"), ordering_key=ordering_key, **attributes)
    elif ordering_key:
        future = publisher.publish(topic, data=data.encode("utf-8"), ordering_key=ordering_key)
    elif attributes:
        future = publisher.publish(topic, data=data.encode("utf-8"), **attributes)
    else:
        future = publisher.publish(topic, data=data.encode("utf-8"))
    print(future.result())
    print(f"Message published to topic: {topic}")

def create_subscription(topic_id, subscription_id):
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_id)
    with pubsub_v1.SubscriberClient() as subscriber:
        sub_path = subscriber.subscription_path(project_id, subscription_id)
        subscriber.create_subscription(request={"name": sub_path, "topic": topic_path, "enable_message_ordering": True})
        print(f"Pull Subscription {sub_path} created for topic {topic_path}")

def callback_and_ack(message: pubsub_v1.subscriber.message.Message) -> None:
    print(f"Received {message}. and the delivery attempt is {message.delivery_attempt}")
    message.ack()

def callback_and_nack(message: pubsub_v1.subscriber.message.Message) -> None:
    print(f"Received message: {message.data} with delivery attempts: {message.delivery_attempt}")
    message.nack()

def read_messages(subscription_id):
    subscriber = pubsub_v1.SubscriberClient()
    subscription_path = subscriber.subscription_path(project_id, subscription_id)
    streaming_pull_future = subscriber.subscribe(subscription_path, callback=callback_and_ack)
    print(f"Listening for messages on {subscription_id}..\n")
    # Wrap subscriber in a 'with' block to automatically call close() when done.
    with subscriber:
        try:
            # When `timeout` is not set, result() will block indefinitely,
            # unless an exception is encountered first.
            streaming_pull_future.result(timeout=5)
        except Exception:
            streaming_pull_future.cancel()  # Trigger the shutdown.
            streaming_pull_future.result()  # Block until the shutdown is complete.

def nack_messages(subscription_id):
    subscriber = pubsub_v1.SubscriberClient()
    subscription_path = subscriber.subscription_path(project_id, subscription_id)
    streaming_pull_future = subscriber.subscribe(subscription_path, callback=callback_and_nack)
    print(f"Listening for messages on {subscription_id} and nack them..\n")
    # Wrap subscriber in a 'with' block to automatically call close() when done.
    with subscriber:
        try:
            # When `timeout` is not set, result() will block indefinitely,
            # unless an exception is encountered first.
            streaming_pull_future.result(timeout=10)
        except Exception as e:
            streaming_pull_future.cancel()  # Trigger the shutdown.

def delete_topic(topic_id):
    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_id)
    publisher.delete_topic(request={"topic": topic_path})

if __name__ == '__main__':
    pub = pubsub_v1.PublisherClient()
    sub = pubsub_v1.SubscriberClient()

    #create_topic("centralstore")
    #create_subscription("centralstore","delstore")
    #publish_message("centralstore", "Laptop=6 qty")
    #publish_message("centralstore", "Printer=4 qty", {"CStoreId": "01"})
    #publish_message("centralstore", "Monitor=8 qty", {"CStoreId": "02"},"ITP")
    #read_messages("mumstore")
    #nack_messages("mumstore")
    #delete_topic("centralstore")