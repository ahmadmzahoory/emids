from google.cloud import pubsub_v1

from main import create_topic, project_id, publish_message, read_messages

def initial_setup():
    topic_path = create_topic(main_topic)
    request = {
        "name": sub_path,
        "topic": topic_path,
        "filter": 'attributes.CStoreId = "01"'
    }
    subscription = sub.create_subscription(request)

if __name__ == "__main__":
    pub = pubsub_v1.PublisherClient()
    sub = pubsub_v1.SubscriberClient()
    main_topic = "centralstore-03"
    sub_topic = "hydstore"
    sub_path = sub.subscription_path(project_id, sub_topic)

    #initial_setup()
    #publish_message(main_topic, "Printer=4 qty", {"CStoreId": "01"})
    #publish_message(main_topic, "Mouse=19 qty", {"CStoreId": "02"})
    #publish_message(main_topic, "Keyboard=34 qty", {"CStoreId": "03"})
    #read_messages(sub_topic)