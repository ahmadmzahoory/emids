from google.api_core.exceptions import DeadlineExceeded
from google.cloud import pubsub_v1
from main import create_topic, project_id, publish_message, read_messages, nack_messages

publisher = pubsub_v1.PublisherClient()
subscriber = pubsub_v1.SubscriberClient()

def initial_setup():
    main_topic = create_topic(main_topic_id)
    dlq_topic = create_topic(dead_letter_topic_id)
    from google.cloud.pubsub_v1.types import DeadLetterPolicy
    dead_letter_policy = DeadLetterPolicy(dead_letter_topic=dlq_topic, max_delivery_attempts=5)
    request = {
        "name": sub_path,
        "topic": main_topic,
        "dead_letter_policy": dead_letter_policy
    }
    subscription = subscriber.create_subscription(request)
    print(f"Subscription created: {subscription.name}")
    print(f"It will forward dead letter messages to : {subscription.dead_letter_policy.dead_letter_topic}")
    print(f"After {subscription.dead_letter_policy.max_delivery_attempts} delivery attempts")
    request = {
        "name": dlq_sub_path,
        "topic": dlq_topic}
    subscription = subscriber.create_subscription(request)

if __name__ == "__main__":
    main_topic_id = "centralstore-02"
    dead_letter_topic_id = "dlq_centralstore-02"
    sub_topic = "blrstore"
    sub_path = subscriber.subscription_path(project_id, sub_topic)
    dlq_sub = "dlq_subscription"
    dlq_sub_path = subscriber.subscription_path(project_id, dlq_sub)

    #initial_setup()
    #publish_message(main_topic_id, "keyboard=18 qty", {"CStoreId": "01"})
    #nack_messages(sub_topic)
    #read_messages(dlq_sub)